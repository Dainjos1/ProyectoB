
package com.mycompany.proyectob;


public class Direcciones {
    
    private String calle;
    private String avenida;
    private String DireccionCompleta;
    private String zona;

    
    
    /**
     * @return the calle
     */
    public String getCalle() {
        return calle;
    }

    /**
     * @param calle the calle to set
     */
    public void setCalle(String calle) {
        this.calle = calle;
    }

    /**
     * @return the avenida
     */
    public String getAvenida() {
        return avenida;
    }

    /**
     * @param avenida the avenida to set
     */
    public void setAvenida(String avenida) {
        this.avenida = avenida;
    }

    /**
     * @return the DireccionCompleta
     */
    public String getDireccionCompleta() {
        return DireccionCompleta;
    }

    /**
     * @param DireccionCompleta the DireccionCompleta to set
     */
    public void setDireccionCompleta(String DireccionCompleta) {
        this.DireccionCompleta = DireccionCompleta;
    }

    /**
     * @return the zona
     */
    public String getZona() {
        return zona;
    }

    /**
     * @param zona the zona to set
     */

    public void setZona(String zona) {
        this.zona = zona;
    }
           
}
